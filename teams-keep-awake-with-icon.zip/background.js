chrome.runtime.onInstalled.addListener(() => {
  console.log("[Teams Keep Awake] Extensão instalada.");
});